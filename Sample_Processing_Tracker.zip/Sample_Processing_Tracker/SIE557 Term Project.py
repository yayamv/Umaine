'''
Kendra Vilfort
Final Project
SIE557 Database Systems Applications
May 2025
'''

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkcalendar import DateEntry
import db_functions as db

rows = None


# Create and open the main application window
def start_app():
    form = tk.Tk()
    form.title("Sample Processing Tracker")
    return form


# Set up tabs in the main window for different functions
def create_tabbed_menu(parent):
    tab_parent = ttk.Notebook(parent)
    tab1 = ttk.Frame(tab_parent)
    tab2 = ttk.Frame(tab_parent)
    tab3 = ttk.Frame(tab_parent)

    # Add tabs for adding samples, processing samples, and tracking samples
    tab_parent.add(tab1, text="Add New Sample")
    tab_parent.add(tab2, text="Sample Processing")
    tab_parent.add(tab3, text="Sample Tracker")

    # Set up the content for each tab
    add_new_samples_tab(tab1)
    sample_processing(tab2)
    sample_search_tab(tab3)

    # Show the tabs on the window
    tab_parent.pack(expand=1, fill="both")
    return True


# Set up the section for adding new samples
def add_new_samples_tab(parent):
    samples_to_add = []  # List to collect samples before they are saved

    # Get sample details and add them to the list
    def add_sample_to_list():
        id = sampID.get()
        typ = sampTyp.get()
        vol = sampVol.get()
        kit = collKit.get()
        date = collDate.get()

        sample_entry = f"ID: {id}, Type: {typ}, Volume: {vol}, Kit: {kit}, Date: {date}"
        samples_to_add.append(sample_entry)  # Add to the sample list
        sample_listbox.insert(tk.END, sample_entry)  # Show in the listbox

        # Clear the input fields
        sampID.set("")
        sampTyp.set("")
        sampVol.set("")
        collKit.set("")
        collDate.set('')

    # Save all collected samples to the database
    def submit_samples():
        if not samples_to_add:
            messagebox.showwarning("Warning", "No samples to submit.")
            return

        for sample in samples_to_add:
            id, typ, vol, kit, date = sample.split(", ")
            try:
                con = db.open_database()  # Connect to the database
            except Exception as e:
                print(e)
                raise Exception("Database connection error")
            try:
                # Prepare and run the SQL command to insert the sample
                sql = "INSERT INTO Samples (Sample_ID, Sample_type, Sample_Volume_uL, Collection_Kit_Type, Collection_Date) VALUES (%s, %s, %s, %s, %s)"
                vals = (id.split(": ")[1], typ.split(": ")[1], vol.split(": ")[1], kit.split(": ")[1],
                        date.split(": ")[1])
                db.insert_database(con, sql, vals)
            except Exception as e:
                raise db.DatabaseError(e)

        # Show a message when samples are successfully added
        messagebox.showinfo("Success", "All samples added successfully!")
        sample_listbox.delete(0, tk.END)  # Clear the displayed list
        samples_to_add.clear()  # Clear the sample list

    # Input fields for sample details
    sampID = tk.StringVar()
    sampTyp = tk.StringVar()
    collKit = tk.StringVar()
    collDate = tk.StringVar()
    sampVol = tk.StringVar()

    # Build the user interface for input fields and labels
    ttk.Label(parent, text="Sample ID:").grid(row=0, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=sampID).grid(row=0, column=1, padx=15, pady=15)

    # Dropdown for selecting sample type
    ttk.Label(parent, text="Sample Type:").grid(row=1, column=0, padx=15, pady=15)
    sample_type_options = ['Blood', 'Tissue', 'Saliva']
    ttk.Combobox(parent, textvariable=sampTyp, values=sample_type_options).grid(row=1, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Sample Volume (uL):").grid(row=2, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=sampVol).grid(row=2, column=1, padx=15, pady=15)

    # Dropdown for selecting collection kit type
    ttk.Label(parent, text="Collection Kit:").grid(row=3, column=0, padx=15, pady=15)
    collection_kit_options = ['Adult Saliva', 'Pediatric Saliva', 'Assisted Saliva', 'Vaccutainer Tube',
                              'Tissue Collection Tube']
    collection_kit_menu = ttk.Combobox(parent, textvariable=collKit, values=collection_kit_options)
    collection_kit_menu.grid(row=3, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Collection Date:").grid(row=4, column=0, padx=15, pady=15)
    collDateEntry = DateEntry(parent, textvariable=collDate, date_pattern='yyyy-mm-dd').grid(row=4, column=1, padx=15,
                                                                                             pady=15)

    # Buttons for adding a sample and submitting all samples
    ttk.Button(parent, text="Add Sample", command=add_sample_to_list).grid(row=5, column=0, padx=15, pady=15)
    ttk.Button(parent, text="Submit All Samples", command=submit_samples).grid(row=5, column=1, padx=15, pady=15)

    sample_listbox = tk.Listbox(parent, width=80, height=10)
    sample_listbox.grid(column=0, row=6, columnspan=2, padx=15, pady=15)


# Set up the section for processing samples
def sample_processing(parent):
    tab_parent = ttk.Notebook(parent)
    sub_tabs = {
        "Extraction": extraction_tab,
        "Quantification": quantification_tab,
        "Dilution": dilution_tab,
        "Validation": validation_tab
    }

    # Create each processing sub-tab
    for tab_name, tab_func in sub_tabs.items():
        sub_tab = ttk.Frame(tab_parent)
        tab_parent.add(sub_tab, text=tab_name)
        tab_func(sub_tab)

    tab_parent.pack(expand=1, fill="both")


# Get all sample IDs from the database
def get_sample_ids():
    global rows
    global num_of_rows
    try:
        con = db.open_database()  # Connect to the database
    except Exception as e:
        raise Exception("Database connection error")
    try:
        sql = "SELECT Sample_ID FROM Samples"
        rows = db.query_database(con, sql, None)  # Query the database for sample IDs
        sample_ids = [row[0] for row in rows]  # Get sample IDs from the results
    except Exception as e:
        raise Exception("Error querying the database")
    return sample_ids


# Set up the section for handling sample extractions
def extraction_tab(parent):
    global Batch_Number
    global Parent_Sample_ID
    global Derived_Sample_ID
    global Extraction_ID
    global Extraction_Date
    global Extraction_Buffer_Volume_uL
    global _100_percent_EtOH_Volume_uL
    global Elution_Buffer_Volume_uL
    global Notes

    extractions_to_add = []  # List for collecting extractions before saving

    # Get extraction details and add them to the list
    def add_extraction_to_list():
        batch_num = batchNumber.get()
        sample_id = parent_sample_id.get()
        derived_sample_id = derived_sampleid.get()
        extraction_date = extractionDate.get()
        extraction_buffer_vol = extractionBufferVol.get()
        etoh_vol = etohVolume.get()
        elution_buffer_vol = elutionBufferVol.get()
        notes = notesText.get("1.0", tk.END).strip()

        # Create a formatted string for the extraction
        extraction_entry = (f"Batch: {batch_num}, Parent ID: {sample_id}, Derived ID: {derived_sample_id}, "
                            f"Date: {extraction_date}, Buffer Vol: {extraction_buffer_vol}, "
                            f"EtOH Vol: {etoh_vol}, Elution Vol: {elution_buffer_vol}, Notes: {notes}")

        extractions_to_add.append(extraction_entry)  # Add to the extractions list
        extraction_listbox.insert(tk.END, extraction_entry)  # Show in the listbox

        # Clear the input fields
        batchNumber.set("")
        parent_sample_id.set("")
        derived_sampleid.set("")
        extractionDate.set("")
        extractionBufferVol.set("")
        etohVolume.set("")
        elutionBufferVol.set("")
        notesText.delete("1.0", tk.END)

    # Save all collected extractions to the database
    def submit_extraction():
        if not extractions_to_add:
            messagebox.showwarning("Warning", "No extractions to submit.")
            return

        for extraction_entry in extractions_to_add:
            batch_num, sample_id, derived_sample_id, extraction_date, extraction_buffer_vol, etoh_vol, elution_buffer_vol, notes = extraction_entry.split(
                ", ")
            try:
                con = db.open_database()  # Connect to the database
            except Exception as e:
                print(e)
                raise Exception("Database connection error")
            try:
                # Prepare and run the SQL command to insert the extraction
                sql = ("INSERT INTO Extraction (Batch_Number, Parent_Sample_ID, Derived_Sample_ID, "
                       "Extraction_Date, Extraction_Buffer_Volume_uL, _100_percent_EtOH_Volume_uL, "
                       "Elution_Buffer_Volume_uL, Notes) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)")
                vals = (batch_num.split(": ")[1], sample_id.split(": ")[1],
                        derived_sample_id.split(": ")[1], extraction_date.split(": ")[1],
                        extraction_buffer_vol.split(": ")[1], etoh_vol.split(": ")[1],
                        elution_buffer_vol.split(": ")[1], notes.split(": ")[1])
                db.insert_database(con, sql, vals)
            except Exception as e:
                raise db.DatabaseError(e)

        messagebox.showinfo("Success", "Extraction data submitted successfully!")  # Confirmation message
        extraction_listbox.delete(0, tk.END)  # Clear the displayed list
        extractions_to_add.clear()  # Clear the extractions list

    # Input fields for extraction details
    batchNumber = tk.StringVar()
    parent_sample_id = tk.StringVar()
    derived_sampleid = tk.StringVar()
    extractionDate = tk.StringVar()
    extractionBufferVol = tk.StringVar()
    etohVolume = tk.StringVar()
    elutionBufferVol = tk.StringVar()

    # Build the user interface for input fields and labels
    ttk.Label(parent, text="Batch Number:").grid(row=0, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=batchNumber).grid(row=0, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Parent Sample ID:").grid(row=1, column=0, padx=15, pady=15)
    sample_ids = get_sample_ids()
    ttk.Combobox(parent, textvariable=parent_sample_id, values=sample_ids).grid(row=1, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Derived Sample ID:").grid(row=2, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=derived_sampleid).grid(row=2, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Extraction Date:").grid(row=3, column=0, padx=15, pady=15)
    DateEntry(parent, textvariable=extractionDate, date_pattern='yyyy-mm-dd').grid(row=3, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Extraction Buffer Volume (uL):").grid(row=4, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=extractionBufferVol).grid(row=4, column=1, padx=15, pady=15)

    ttk.Label(parent, text="100% EtOH Volume (uL):").grid(row=5, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=etohVolume).grid(row=5, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Elution Buffer Volume (uL):").grid(row=6, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=elutionBufferVol).grid(row=6, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Notes:").grid(row=7, column=0, padx=15, pady=15)
    notesText = tk.Text(parent, height=2, width=20)
    notesText.grid(row=7, column=1, padx=15, pady=15)

    # Buttons for adding an extraction and submitting all extractions
    ttk.Button(parent, text="Add Extraction", command=add_extraction_to_list).grid(row=8, column=0, padx=15, pady=15)
    ttk.Button(parent, text="Submit Extractions", command=submit_extraction).grid(row=8, column=1, padx=15, pady=15)

    extraction_listbox = tk.Listbox(parent, width=150, height=10)
    extraction_listbox.grid(column=0, row=9, columnspan=2, padx=15, pady=15)


# Set up the section for handling sample quantifications
def quantification_tab(parent):
    global quantification_id
    global quantification_date
    global concentration
    global quant_instrument
    global sample_id

    quantifications_to_add = []  # List for collecting quantifications before saving

    # Get quantification details and add them to the list
    def add_quantification_to_list():
        quantification_date = quant_date.get()
        concentration = conc.get()
        quantification_instrument = quant_instrument.get()
        sample_id = sampleid.get()

        # Create a formatted string for the quantification
        quantification_entry = (f"Sample ID: {sample_id}, Date: {quantification_date}, "
                                f"Concentration: {concentration}, Instrument: {quantification_instrument}")

        quantifications_to_add.append(quantification_entry)  # Add to the quantifications list
        quantification_listbox.insert(tk.END, quantification_entry)  # Show in the listbox

        # Clear the input fields
        quant_date.set("")
        conc.set("")
        quant_instrument.set("")
        sampleid.set("")

    # Save all collected quantifications to the database
    def submit_quantification():
        if not quantifications_to_add:
            messagebox.showwarning("Warning", "No quantifications to submit.")
            return

        for quantification_entry in quantifications_to_add:
            sample_id, quantification_date, concentration, quantification_instrument = quantification_entry.split(", ")
            try:
                con = db.open_database()  # Connect to the database
            except Exception as e:
                print(e)
                raise Exception("Database connection error")
            try:
                # Prepare and run the SQL command to insert the quantification
                sql = ("INSERT INTO Quantification "
                       "(Samples_Sample_ID, Quantification_Date, Concentration, Quantification_Instrument) "
                       "VALUES (%s, %s, %s, %s)")
                vals = (sample_id.split(": ")[1],
                        quantification_date.split(": ")[1],
                        concentration.split(": ")[1],
                        quantification_instrument.split(": ")[1])
                db.insert_database(con, sql, vals)
            except Exception as e:
                raise db.DatabaseError(e)

        messagebox.showinfo("Success", "Quantification data submitted successfully!")  # Confirmation message
        quantification_listbox.delete(0, tk.END)  # Clear the displayed list
        quantifications_to_add.clear()  # Clear the quantifications list

    # Input fields for quantification details
    quant_date = tk.StringVar()
    conc = tk.StringVar()
    quant_instrument = tk.StringVar()
    sampleid = tk.StringVar()

    # Build the user interface for input fields and labels
    ttk.Label(parent, text="Sample ID:").grid(row=0, column=0, padx=15, pady=15)
    sample_ids = get_sample_ids()
    ttk.Combobox(parent, textvariable=sampleid, values=sample_ids).grid(row=0, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Quantification Date:").grid(row=1, column=0, padx=15, pady=15)
    DateEntry(parent, textvariable=quant_date, date_pattern='yyyy-mm-dd').grid(row=1, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Concentration (ng/uL):").grid(row=2, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=conc).grid(row=2, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Quantification Instrument:").grid(row=3, column=0, padx=15, pady=15)
    instruments = ["Qubit"]
    ttk.Combobox(parent, textvariable=quant_instrument, values=instruments).grid(row=3, column=1, padx=15, pady=15)

    # Buttons for adding a quantification and submitting all quantifications
    ttk.Button(parent, text="Add Quantification", command=add_quantification_to_list).grid(row=4, column=0, padx=15,
                                                                                           pady=15)
    ttk.Button(parent, text="Submit Quantification", command=submit_quantification).grid(row=4, column=1, padx=15,
                                                                                         pady=15)

    quantification_listbox = tk.Listbox(parent, width=80, height=10)
    quantification_listbox.grid(column=0, row=5, columnspan=2, padx=15, pady=15)


# Set up the section for handling sample dilutions
def dilution_tab(parent):
    global dilution_id
    global dilution_date
    global dilution_volume
    global dilution_concentration
    global aliquot_sample_id
    global parent_sample_id

    dilutions_to_add = []  # List for collecting dilutions before saving

    # Get dilution details and add them to the list
    def add_dilution_to_list():
        dilution_date = dilutionDate.get()
        dilution_volume = dilutionVolume.get()
        dilution_concentration = dilutionConcentration.get()
        aliquot_sample_id = aliquotSampleID.get()
        parent_sample_id = parentSampleID.get()

        # Create a formatted string for the dilution
        dilution_entry = (f"Date: {dilution_date}, Volume: {dilution_volume}, "
                          f"Concentration: {dilution_concentration}, Aliquot ID: {aliquot_sample_id}, Parent ID: {parent_sample_id}")

        dilutions_to_add.append(dilution_entry)  # Add to the dilutions list
        dilution_listbox.insert(tk.END, dilution_entry)  # Show in the listbox

        # Clear the input fields
        dilutionDate.set("")
        dilutionVolume.set("")
        dilutionConcentration.set("")
        aliquotSampleID.set("")
        parentSampleID.set("")

    # Save all collected dilutions to the database
    def submit_dilution():
        if not dilutions_to_add:
            messagebox.showwarning("Warning", "No dilutions to submit.")
            return

        for dilution_entry in dilutions_to_add:
            dilution_date, dilution_volume, dilution_concentration, aliquot_sample_id, parent_sample_id = dilution_entry.split(
                ", ")
            try:
                con = db.open_database()  # Connect to the database
            except Exception as e:
                print(e)
                raise Exception("Database connection error")
            try:
                # Prepare and run the SQL command to insert the dilution
                sql = ("INSERT INTO Dilution (Dilution_Date, Dilution_Volume, Dilution_Concentration, "
                       "Aliquot_Sample_ID, Parent_Sample_ID) VALUES (%s, %s, %s, %s, %s)")
                vals = (dilution_date.split(": ")[1], dilution_volume.split(": ")[1],
                        dilution_concentration.split(": ")[1],
                        aliquot_sample_id.split(": ")[1], parent_sample_id.split(": ")[1])
                db.insert_database(con, sql, vals)
            except Exception as e:
                raise db.DatabaseError(e)

        messagebox.showinfo("Success", "Dilution data submitted successfully!")  # Confirmation message
        dilution_listbox.delete(0, tk.END)  # Clear the displayed list
        dilutions_to_add.clear()  # Clear the dilutions list

    # Input fields for dilution details
    dilutionDate = tk.StringVar()
    dilutionVolume = tk.StringVar()
    dilutionConcentration = tk.StringVar()
    aliquotSampleID = tk.StringVar()
    parentSampleID = tk.StringVar()

    # Build the user interface for input fields and labels
    ttk.Label(parent, text="Parent Sample ID:").grid(row=1, column=0, padx=15, pady=15)
    sample_ids = get_sample_ids()
    ttk.Combobox(parent, textvariable=parentSampleID, values=sample_ids).grid(row=1, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Aliquot Sample ID:").grid(row=2, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=aliquotSampleID).grid(row=2, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Dilution Date:").grid(row=3, column=0, padx=15, pady=15)
    DateEntry(parent, textvariable=dilutionDate, date_pattern='yyyy-mm-dd').grid(row=3, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Dilution Volume (uL):").grid(row=4, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=dilutionVolume).grid(row=4, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Dilution Concentration (ng/uL):").grid(row=5, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=dilutionConcentration).grid(row=5, column=1, padx=15, pady=15)

    # Buttons for adding a dilution and submitting all dilutions
    ttk.Button(parent, text="Add Dilution", command=add_dilution_to_list).grid(row=6, column=0, pady=15)
    ttk.Button(parent, text="Submit Dilution", command=submit_dilution).grid(row=6, column=1, pady=15)

    dilution_listbox = tk.Listbox(parent, width=80, height=10)
    dilution_listbox.grid(column=0, row=7, columnspan=2, padx=15, pady=15)


# Set up the section for handling sample validations
def validation_tab(parent):
    global Batch_Number
    global Validation_Date
    global Gel_Image
    global Samples_Sample_ID

    validations_to_add = []  # List for collecting validations before saving

    # Get validation details and add them to the list
    def add_validation_to_list():
        validation_date = validationDate.get()
        gel_image = gelImage.get()
        sample_id = sampleid.get()

        # Create a formatted string for the validation
        validation_entry = (f"Date: {validation_date}, Gel Image: {gel_image}, Sample ID: {sample_id}")

        validations_to_add.append(validation_entry)  # Add to the validations list
        validation_listbox.insert(tk.END, validation_entry)  # Show in the listbox

        # Clear the input fields
        validationID.set("")
        validationDate.set("")
        gelImage.set("")
        sampleid.set("")

    # Save all collected validations to the database
    def submit_validation():
        if not validations_to_add:
            messagebox.showwarning("Warning", "No validations to submit.")
            return

        for validation_entry in validations_to_add:
            validation_date, gel_image, sample_id = validation_entry.split(", ")
            try:
                con = db.open_database()  # Connect to the database
            except Exception as e:
                print(e)
                raise Exception("Database connection error")
            try:
                # Prepare and run the SQL command to insert the validation
                sql = ("INSERT INTO Validation (Validation_Date, Gel_Image, Samples_Sample_ID) "
                       "VALUES (%s, %s, %s)")
                vals = (validation_date.split(": ")[1],
                        gel_image.split(": ")[1], sample_id.split(": ")[1])
                db.insert_database(con, sql, vals)
            except Exception as e:
                raise db.DatabaseError(e)

        messagebox.showinfo("Success", "Validation data submitted successfully!")  # Confirmation message
        validation_listbox.delete(0, tk.END)  # Clear the displayed list
        validations_to_add.clear()  # Clear the validations list

    # Open a file dialog to select a gel image
    def import_gel_image():
        file_path = filedialog.askopenfilename(title="Select Gel Image",
                                               filetypes=(("Image Files", "*.png;*.jpg;*.jpeg;*.gif"),
                                                          ("All Files", "*.*")))
        if file_path:
            gelImage.set(file_path)  # Set the path of the selected gel image

    # Input fields for validation details
    validationDate = tk.StringVar()
    gelImage = tk.StringVar()
    sampleid = tk.StringVar()

    # Build the user interface for input fields and labels
    ttk.Label(parent, text="Validation Date:").grid(row=1, column=0, padx=15, pady=15)
    validationDateEntry = DateEntry(parent, textvariable=validationDate, date_pattern='yyyy-mm-dd')
    validationDateEntry.grid(row=1, column=1, padx=15, pady=15)

    ttk.Label(parent, text="Gel Image (Path):").grid(row=2, column=0, padx=15, pady=15)
    ttk.Entry(parent, textvariable=gelImage, state='readonly').grid(row=2, column=1, padx=15, pady=15)
    ttk.Button(parent, text="Import Gel Image", command=import_gel_image).grid(row=2, column=2, padx=15, pady=15)

    ttk.Label(parent, text="Parent Sample ID:").grid(row=1, column=0, padx=15, pady=15)
    sample_ids = get_sample_ids()
    ttk.Combobox(parent, textvariable=sampleid, values=sample_ids).grid(row=1, column=1, padx=15, pady=15)

    # Buttons for adding a validation and submitting all validations
    ttk.Button(parent, text="Add Validation", command=add_validation_to_list).grid(row=4, column=0, padx=15, pady=15)
    ttk.Button(parent, text="Submit Validations", command=submit_validation).grid(row=4, column=1, padx=15, pady=15)

    validation_listbox = tk.Listbox(parent, width=80, height=10)
    validation_listbox.grid(column=0, row=5, columnspan=2, padx=15, pady=15)


# Set up the section for searching through sample tables
def sample_search_tab(parent):
    selected_table = tk.StringVar()  # Variable to hold the selected table name
    tables = ['Samples', 'Extraction', 'Quantification', 'Dilution', 'Validation']  # List of available tables

    ttk.Label(parent, text="Select Table:").grid(row=0, column=0, padx=15, pady=15)
    table_menu = ttk.Combobox(parent, textvariable=selected_table, values=tables)
    table_menu.grid(row=0, column=1, padx=15, pady=15)

    # Buttons for fetching and exporting data from the selected table
    ttk.Button(parent, text="Get Table Data", command=lambda: get_table_data(selected_table.get())).grid(row=1,
                                                                                                         columnspan=2,
                                                                                                         pady=15)
    ttk.Button(parent, text="Export to CSV", command=lambda: export_to_csv(selected_table.get())).grid(row=2,
                                                                                                       columnspan=2,
                                                                                                       pady=15)

    results_text = tk.Text(parent, width=180, height=20)
    results_text.grid(column=0, row=3, columnspan=2, padx=15, pady=15)

    # Get data from the selected table and display it
    def get_table_data(table_name):
        try:
            con = db.open_database()  # Connect to the database
            with con.cursor() as cursor:
                sql = f"SELECT * FROM {table_name}"  # SQL command to get all data from the table
                cursor.execute(sql)
                results = cursor.fetchall()  # Get the results
                headers = [i[0] for i in cursor.description]  # Get column names
                display_search_results(headers, results)  # Show the results
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            con.close()  # Make sure the database connection is closed

    # Show the table data in the results area
    def display_search_results(headers, results):
        results_text.delete(1.0, tk.END)  # Clear previous results
        results_text.insert(tk.END, " | ".join(headers) + "\n")  # Show the column names
        results_text.insert(tk.END, "-" * 80 + "\n")  # Add a separator line
        if results:
            for row in results:
                # Format and display each row of results
                row_data = ", ".join(map(str, row))
                results_text.insert(tk.END, f"{row_data}\n")
        else:
            results_text.insert(tk.END, "No results found.")

    # Export data from the selected table to a CSV file
    def export_to_csv(table_name):
        try:
            con = db.open_database()  # Connect to the database
            with con.cursor() as cursor:
                sql = f"SELECT * FROM {table_name}"
                cursor.execute(sql)
                results = cursor.fetchall()  # Get the results
                headers = [i[0] for i in cursor.description]  # Get column names

                if results:  # Check if there is data to export
                    with open(f"{table_name}_results.csv", "w", newline='') as csvfile:
                        writer = csv.writer(csvfile)  # Create a CSV writer
                        writer.writerow(headers)  # Write the column names
                        writer.writerows(results)  # Write the data rows
                    messagebox.showinfo("Success", "Data exported successfully!")  # Confirmation message
                else:
                    messagebox.showinfo("No Data", "No results to export.")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            con.close()  # Make sure the database connection is closed


app = start_app()  # Start the application

# Connect to the database initially
try:
    db.open_database()  # Connect to the database
    create_tabbed_menu(app)  # Create the tabbed menu
except Exception as e:
    messagebox.showinfo("Sample Processing Tracker", str(e))  # Show an error message
    exit(0)

app.mainloop()  # Start the main loop for the application
