-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 05, 2025 at 05:03 PM
-- Server version: 5.7.24
-- PHP Version: 8.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sie557_term_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `dilution`
--

CREATE TABLE `dilution` (
  `Dilution_ID` int(11) NOT NULL,
  `Dilution_Date` date DEFAULT NULL,
  `Dilution_Volume` float NOT NULL,
  `Dilution_Concentration` float NOT NULL,
  `Aliquot_Sample_ID` varchar(45) NOT NULL,
  `Parent_Sample_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dilution`
--

INSERT INTO `dilution` (`Dilution_ID`, `Dilution_Date`, `Dilution_Volume`, `Dilution_Concentration`, `Aliquot_Sample_ID`, `Parent_Sample_ID`) VALUES
(1, '2025-05-05', 100, 10, '202512345_1.1.1', '202512345_1.1'),
(2, '2025-05-05', 100, 10, '202512345_1.1.2', '202512345_1.1');

--
-- Triggers `dilution`
--
DELIMITER $$
CREATE TRIGGER `Dilution_BEFORE_INSERT` BEFORE INSERT ON `dilution` FOR EACH ROW BEGIN
    INSERT INTO `Samples` 
    (`Sample_ID`, `Sample_type`, `Collection_Date`, `Sample_Volume_uL`)
    VALUES 
    (NEW.Aliquot_Sample_ID, 'DNA_aliquot', NEW.Dilution_Date, NEW.Dilution_Volume);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `extraction`
--

CREATE TABLE `extraction` (
  `Batch_Number` int(11) NOT NULL,
  `Extraction_ID` int(11) NOT NULL,
  `Extraction_Date` date NOT NULL,
  `Extraction_Buffer_Volume_uL` float DEFAULT NULL,
  `_100_percent_EtOH_Volume_uL` float DEFAULT NULL,
  `Elution_Buffer_Volume_uL` float DEFAULT NULL,
  `Notes` varchar(255) DEFAULT NULL,
  `Derived_Sample_ID` varchar(45) NOT NULL,
  `Parent_Sample_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `extraction`
--

INSERT INTO `extraction` (`Batch_Number`, `Extraction_ID`, `Extraction_Date`, `Extraction_Buffer_Volume_uL`, `_100_percent_EtOH_Volume_uL`, `Elution_Buffer_Volume_uL`, `Notes`, `Derived_Sample_ID`, `Parent_Sample_ID`) VALUES
(111, 1, '2025-05-05', 10, 100, 100, 'Notes!', '202512345_1.1', '202512345_1'),
(111, 2, '2025-05-05', 22, 100, 100, 'Note', '202512345_2.1', '202512345_2'),
(111, 3, '2025-05-05', 12, 100, 100, '', '202512345_3.1', '202512345_3'),
(112, 4, '2025-05-05', 15, 100, 100, '', '202512345_4.1', '202512345_4');

--
-- Triggers `extraction`
--
DELIMITER $$
CREATE TRIGGER `Extraction_BEFORE_INSERT` BEFORE INSERT ON `extraction` FOR EACH ROW BEGIN
    INSERT INTO `Samples` 
    (`Sample_ID`, `Sample_type`, `Collection_Date`, `Sample_Volume_uL`)
    VALUES 
    (NEW.Derived_Sample_ID, 'DNA_extract', NEW.Extraction_Date, NEW.Elution_Buffer_Volume_uL);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `quantification`
--

CREATE TABLE `quantification` (
  `Quantification_ID` int(11) NOT NULL,
  `Quantification_Date` date NOT NULL,
  `Concentration` float NOT NULL,
  `Quantification_Instrument` varchar(45) NOT NULL,
  `Samples_Sample_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quantification`
--

INSERT INTO `quantification` (`Quantification_ID`, `Quantification_Date`, `Concentration`, `Quantification_Instrument`, `Samples_Sample_ID`) VALUES
(1, '2025-05-05', 32, 'Qubit', '202512345_1.1'),
(2, '2025-05-05', 34, 'Qubit', '202512345_2.1'),
(3, '2025-05-05', 22, 'Qubit', '202512345_3.1');

-- --------------------------------------------------------

--
-- Table structure for table `samples`
--

CREATE TABLE `samples` (
  `Sample_ID` varchar(255) NOT NULL,
  `Sample_type` varchar(255) DEFAULT NULL,
  `Collection_Kit_Type` varchar(255) DEFAULT NULL,
  `Collection_Date` date DEFAULT NULL,
  `Sample_Volume_uL` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `samples`
--

INSERT INTO `samples` (`Sample_ID`, `Sample_type`, `Collection_Kit_Type`, `Collection_Date`, `Sample_Volume_uL`) VALUES
('202512345_1', 'Saliva', 'Pediatric Saliva', '2025-05-05', 12),
('202512345_1.1', 'DNA_extract', NULL, '2025-05-05', 100),
('202512345_1.1.1', 'DNA_aliquot', NULL, '2025-05-05', 100),
('202512345_1.1.2', 'DNA_aliquot', NULL, '2025-05-05', 100),
('202512345_2', 'Saliva', 'Adult Saliva', '2025-05-05', 12),
('202512345_2.1', 'DNA_extract', NULL, '2025-05-05', 100),
('202512345_3', 'Saliva', 'Adult Saliva', '2025-05-05', 12),
('202512345_3.1', 'DNA_extract', NULL, '2025-05-05', 100),
('202512345_4', 'Saliva', 'Adult Saliva', '2025-05-05', 14),
('202512345_4.1', 'DNA_extract', NULL, '2025-05-05', 100);

-- --------------------------------------------------------

--
-- Table structure for table `validation`
--

CREATE TABLE `validation` (
  `Validation_ID` int(11) NOT NULL,
  `Validation_Date` date DEFAULT NULL,
  `Gel_Image` blob,
  `Samples_Sample_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `validation`
--

INSERT INTO `validation` (`Validation_ID`, `Validation_Date`, `Gel_Image`, `Samples_Sample_ID`) VALUES
(1, '2025-05-05', 0x433a2f55736572732f4b656e64722f446f776e6c6f6164732f416761726f73652d67656c2d656c656374726f70686f72657369732d31352d6f662d5043522d616d706c696669636174696f6e2d666f722d444e412d73686f77696e672d38303062702d6f662e706e67, '202512345_1.1.2'),
(2, '2025-05-05', 0x433a2f55736572732f4b656e64722f446f776e6c6f6164732f416761726f73652d67656c2d656c656374726f70686f72657369732d31352d6f662d5043522d616d706c696669636174696f6e2d666f722d444e412d73686f77696e672d38303062702d6f662e706e67, '202512345_2.1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dilution`
--
ALTER TABLE `dilution`
  ADD PRIMARY KEY (`Dilution_ID`,`Parent_Sample_ID`),
  ADD KEY `fk_Dilution_Samples1_idx` (`Parent_Sample_ID`);

--
-- Indexes for table `extraction`
--
ALTER TABLE `extraction`
  ADD PRIMARY KEY (`Extraction_ID`,`Parent_Sample_ID`),
  ADD KEY `fk_Extraction_Samples_idx` (`Parent_Sample_ID`);

--
-- Indexes for table `quantification`
--
ALTER TABLE `quantification`
  ADD PRIMARY KEY (`Quantification_ID`,`Samples_Sample_ID`),
  ADD KEY `fk_Quantification_Samples1_idx` (`Samples_Sample_ID`);

--
-- Indexes for table `samples`
--
ALTER TABLE `samples`
  ADD PRIMARY KEY (`Sample_ID`);

--
-- Indexes for table `validation`
--
ALTER TABLE `validation`
  ADD PRIMARY KEY (`Validation_ID`,`Samples_Sample_ID`),
  ADD KEY `fk_Validation_Samples1_idx` (`Samples_Sample_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dilution`
--
ALTER TABLE `dilution`
  MODIFY `Dilution_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `extraction`
--
ALTER TABLE `extraction`
  MODIFY `Extraction_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `quantification`
--
ALTER TABLE `quantification`
  MODIFY `Quantification_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `validation`
--
ALTER TABLE `validation`
  MODIFY `Validation_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dilution`
--
ALTER TABLE `dilution`
  ADD CONSTRAINT `fk_Dilution_Samples1` FOREIGN KEY (`Parent_Sample_ID`) REFERENCES `samples` (`Sample_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `extraction`
--
ALTER TABLE `extraction`
  ADD CONSTRAINT `fk_Extraction_Samples` FOREIGN KEY (`Parent_Sample_ID`) REFERENCES `samples` (`Sample_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `quantification`
--
ALTER TABLE `quantification`
  ADD CONSTRAINT `fk_Quantification_Samples1` FOREIGN KEY (`Samples_Sample_ID`) REFERENCES `samples` (`Sample_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `validation`
--
ALTER TABLE `validation`
  ADD CONSTRAINT `fk_Validation_Samples1` FOREIGN KEY (`Samples_Sample_ID`) REFERENCES `samples` (`Sample_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
